const apiId = '0zf6cghiv8'
export const apiEndpoint = `https://${apiId}.execute-api.us-east-1.amazonaws.com/prod`
